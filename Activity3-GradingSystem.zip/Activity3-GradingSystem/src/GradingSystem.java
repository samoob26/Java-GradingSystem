import java.util.Scanner;

public class GradingSystem {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        System.out.print("Prelim Grade: ");
        int prelimGrade = s.nextInt();
        System.out.print("Midterm Grade: ");
        int midtermGrade = s.nextInt();
        System.out.print("Final Grade: ");
        int finalGrade = s.nextInt();

        int average = (prelimGrade + midtermGrade + finalGrade)/3;
        System.out.println();
        System.out.println("General Average: " + average);

        if(average>=94){
            System.out.println("Excellent");
        } else if(average>=88){
            System.out.println("Very Good");
        } else if (average>=82){
            System.out.println("Good");
        } else if (average>=79){
            System.out.println("satifactory");
        } else if (average>=76){
            System.out.println("Fair");
        } else if (average>=75){
            System.out.println("passed");
        } else {
            System.out.println("Failed");
        }

    }
}